# 📱 CARA UPLOAD WEBSITE KE VERCEL - VERSI SIMPEL

## 🎯 3 Langkah Mudah (5 Menit!)

---

## LANGKAH 1: DOWNLOAD WEBSITE DARI FIGMA MAKE

### Cara Download:
1. **Cari tombol "Download" atau "Export"** di Figma Make
2. **Klik tombol tersebut**
3. Website akan ter-download sebagai **file ZIP**
4. Buka folder **Downloads** di komputer Anda
5. **Klik kanan file ZIP** → Pilih **"Extract All"** (Windows) atau **"Unzip"** (Mac)
6. Sekarang Anda punya **folder website** ✅

**Tampilan folder yang benar:**
```
📁 berkah-dental-website/
  ├── 📁 src/
  ├── 📁 public/
  ├── 📄 package.json
  ├── 📄 index.html
  └── ... file lainnya
```

---

## LANGKAH 2: BUKA & LOGIN KE VERCEL

### 2.1 Buka Website Vercel
1. Buka browser (Chrome/Firefox/Edge)
2. Ketik: **https://vercel.com**
3. Tekan **Enter**

### 2.2 Login/Daftar Akun
**Pilih salah satu cara login:**

**Cara 1: Pakai Google (PALING MUDAH)** ⭐
1. Klik tombol **"Continue with Google"**
2. Pilih akun Google Anda
3. Klik **"Allow"** atau **"Izinkan"**
4. **Selesai!** Anda masuk ke Vercel Dashboard

**Cara 2: Pakai GitHub (Recommended untuk update website nanti)**
1. Jika belum punya GitHub:
   - Buka tab baru: **https://github.com**
   - Klik **"Sign Up"** (pojok kanan atas)
   - Isi: Email, Password, Username
   - Verifikasi email Anda
   - **Selesai!** Akun GitHub sudah jadi
2. Kembali ke Vercel
3. Klik tombol **"Continue with GitHub"**
4. Klik **"Authorize Vercel"**
5. **Selesai!** Anda masuk ke Vercel Dashboard

**Cara 3: Pakai Email**
1. Klik **"Continue with Email"**
2. Masukkan email Anda
3. Cek inbox email → klik link verifikasi
4. **Selesai!** Anda masuk ke Vercel Dashboard

---

## LANGKAH 3: UPLOAD WEBSITE KE VERCEL

### 3.1 Klik Tombol "Add New"
1. Setelah login, Anda akan lihat **Vercel Dashboard**
2. Cari tombol **"Add New..."** di pojok kanan atas
3. **Klik tombol tersebut**
4. Pilih **"Project"**

### 3.2 Upload Folder Website
**Ada 2 cara:**

**Cara A: DRAG & DROP (Paling Mudah)** ⭐
1. Buka folder website yang sudah Anda extract tadi
2. **SERET (drag) folder tersebut** ke kotak upload di Vercel
3. **Lepas (drop)** di dalam kotak
4. ✅ Folder akan ter-upload otomatis!

**Cara B: Browse Manual**
1. Klik tombol **"Browse"** atau **"Select Folder"**
2. Cari folder website Anda
3. **Pilih folder** tersebut
4. Klik **"Open"** atau **"Select"**
5. ✅ Folder akan ter-upload!

### 3.3 Cek Pengaturan (Biasanya Sudah Otomatis)
Vercel akan otomatis mendeteksi:
- ✅ **Framework:** Vite
- ✅ **Build Command:** npm run build
- ✅ **Output Directory:** dist

**Jangan ubah apa-apa!** Biarkan seperti itu.

### 3.4 Klik Tombol "Deploy"
1. Cari tombol besar berwarna biru: **"Deploy"**
2. **KLIK tombol tersebut**
3. **JANGAN tutup browser!**
4. Tunggu proses deploy... ⏱️

**Proses deploy akan memakan waktu:**
- ⏱️ Sekitar **2-3 menit**
- Anda akan lihat loading animation
- Ada teks yang berjalan (log proses build)

### 3.5 Website Online! 🎉
Setelah selesai, Anda akan lihat:
- ✅ Pesan: **"Congratulations!"** atau **"Success!"**
- ✅ Gambar confetti/kembang api 🎊
- ✅ **Link website Anda**, contoh:
  - `berkah-dental-abc123.vercel.app`
  - `your-project-xyz456.vercel.app`

**KLIK LINK TERSEBUT** untuk membuka website Anda!

---

## ✅ CHECKLIST: WEBSITE BERHASIL ONLINE

Pastikan semua ini berfungsi:

### Test di Komputer/Laptop:
- [ ] Website terbuka dengan benar
- [ ] Semua gambar muncul
- [ ] Klik button **"Book Appointment"** → WhatsApp terbuka
- [ ] Isi form booking → Submit → WhatsApp terbuka dengan data yang diisi
- [ ] Scroll semua section (Services, About, Testimonials, Contact)

### Test di HP/Smartphone:
- [ ] Buka link website di HP
- [ ] Klik **menu hamburger** (3 garis) di pojok kanan atas
- [ ] Menu terbuka dengan benar
- [ ] Klik button **"Book Appointment"** → WhatsApp terbuka
- [ ] Isi form booking → WhatsApp terbuka dengan data

**Jika semua ✅ → Website Anda SUKSES online!** 🎉

---

## 🌐 LINK WEBSITE ANDA

Setelah deploy sukses, Anda akan dapat:

### Domain Gratis dari Vercel:
```
https://your-project-abc123.vercel.app
```

**Copy link ini dan share ke:**
- ✅ Instagram (bio atau story)
- ✅ Facebook (page atau profile)
- ✅ WhatsApp Status
- ✅ TikTok bio
- ✅ Google My Business
- ✅ Kartu nama digital

---

## 💡 TIPS SETELAH ONLINE

### 1. Save Link Website Anda
- Copy link: `your-project.vercel.app`
- **Save di Notes HP Anda**
- Share ke customer kapan saja

### 2. Test Booking WhatsApp
- Buka website
- Coba klik **"Book Appointment"**
- Pastikan WhatsApp terbuka ke nomor: **+62 895-3022-8432**
- Pastikan pesan otomatis muncul

### 3. Share ke Media Sosial
**Instagram:**
- Buka profile → Edit Profile
- Paste link website di bagian **"Website"**
- Save

**Facebook:**
- Buka Page bisnis Anda
- Edit Info
- Tambahkan link website
- Save

**WhatsApp Business:**
- Setting → Business Tools → Catalog
- Tambahkan link website di deskripsi

---

## ❌ TROUBLESHOOTING (JIKA ADA MASALAH)

### Problem 1: Website Tidak Terbuka
**Coba:**
1. Refresh browser (tekan F5)
2. Coba buka di browser lain (Chrome/Firefox/Safari)
3. Tunggu 5-10 menit lalu coba lagi

### Problem 2: WhatsApp Button Tidak Jalan
**Solusi:**
1. Test klik button dari HP (bukan komputer)
2. Pastikan Anda punya WhatsApp terinstall
3. Jika masih error, hubungi developer

### Problem 3: Gambar Tidak Muncul
**Solusi:**
1. Tunggu 5 menit (kadang gambar load lebih lama)
2. Refresh browser (tekan F5)
3. Clear cache browser:
   - Chrome: Ctrl+Shift+Del → Clear cache
   - Firefox: Ctrl+Shift+Del → Clear cache

### Problem 4: "Build Failed" / Deploy Gagal
**Solusi:**
1. **COBA LAGI** - Klik tombol **"Redeploy"**
2. Jika masih gagal:
   - Cek apakah semua file ter-upload dengan benar
   - Pastikan file `package.json` ada di root folder
   - Upload ulang dari awal

**Jika masih error, screenshot pesan error dan tanyakan ke developer!**

---

## 🎓 PENJELASAN ISTILAH (Agar Tidak Bingung)

| Istilah | Artinya |
|---------|---------|
| **Deploy** | Proses upload & online-kan website |
| **Vercel** | Platform hosting website (gratis) |
| **Domain** | Alamat website (contoh: `berkahdental.com`) |
| **Dashboard** | Halaman kontrol panel Vercel |
| **Build** | Proses kompilasi code menjadi website |
| **GitHub** | Platform untuk simpan code |
| **Framework** | Teknologi yang dipakai (React/Vite) |

---

## 📞 INFO KONTAK WEBSITE

- **Nomor WhatsApp Admin:** +62 895-3022-8432
- **Website:** `[your-website].vercel.app` (ganti setelah deploy)
- **Teknologi:** React + Tailwind CSS
- **Hosting:** Vercel (Gratis selamanya!)

---

## 🎉 SELAMAT! WEBSITE ANDA ONLINE!

**Apa yang sudah Anda capai:**
✅ Website online 24/7  
✅ Bisa diakses dari mana saja  
✅ WhatsApp booking otomatis  
✅ Responsive (bagus di HP & komputer)  
✅ HTTPS/SSL (aman & terpercaya)  
✅ Gratis selamanya!  

**Sekarang tinggal promosi dan dapat customer! 💪**

---

## 📚 FILE PANDUAN LAINNYA

Jika butuh panduan lebih detail:
- **QUICK-START.md** - Panduan ringkas
- **PANDUAN-DEPLOY-VERCEL.md** - Panduan lengkap dengan gambar
- **CARA-GANTI-NOMOR-WA.md** - Cara ganti nomor WhatsApp

---

**Sukses untuk bisnis dental clinic Anda! 🦷✨**

Dibuat dengan ❤️ oleh Figma Make Assistant
