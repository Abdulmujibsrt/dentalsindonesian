# 📱 Cara Mengubah Nomor WhatsApp Admin

## 🎯 Lokasi File

Buka file: `/src/app/App.tsx`

## 📝 Langkah-Langkah:

### 1. Cari Baris Ini (Sekitar Baris 20):

```javascript
const whatsappNumber = '6281234567890'; // GANTI INI!
```

### 2. Ganti Dengan Nomor WhatsApp Anda

**Format yang BENAR:**
- Hapus angka 0 di depan
- Tambahkan kode negara 62 (Indonesia)
- Tanpa tanda +, -, atau spasi

**Contoh:**

| Nomor Asli | Format yang Benar |
|------------|-------------------|
| 0812-3456-7890 | 6281234567890 |
| 0857-1234-5678 | 6285712345678 |
| +62 821 9876 5432 | 6282198765432 |

### 3. Simpan File

Setelah mengubah, save file dan website Anda siap!

---

## ✨ Fitur WhatsApp Yang Sudah Terpasang:

### 1️⃣ **Button "Book Appointment"**
- Di navigation bar (atas)
- Di mobile menu
- Di hero section
- Langsung buka WhatsApp dengan pesan standar

### 2️⃣ **Form Booking Lengkap**
- User isi: Nama, Email, Telepon, Tanggal, Keluhan
- Saat klik "Submit Request", WhatsApp terbuka otomatis
- Pesan sudah terformat rapi dengan emoji
- Form otomatis kosong setelah submit

### 3️⃣ **Format Pesan WhatsApp**

Pesan yang dikirim akan terlihat seperti ini:

```
*BOOKING APPOINTMENT - BrightSmile Dental*

📋 *Data Pasien:*
👤 Nama: Ahmad Rizki
📧 Email: ahmad@email.com
📱 Telepon: 081234567890
📅 Tanggal Pilihan: 2024-12-25

💬 *Keluhan/Kebutuhan:*
Sakit gigi, ingin konsultasi pemasangan gigi palsu

---
Mohon konfirmasi ketersediaan jadwal. Terima kasih! 🦷
```

---

## 🔧 Jika Ingin Mengubah Pesan WhatsApp:

### Lokasi 1: Quick Booking (Button tanpa form)
Baris ~68-70:
```javascript
const handleQuickBooking = () => {
  const message = encodeURIComponent('Halo! Saya ingin booking appointment di BrightSmile Dental. Mohon informasi jadwal yang tersedia. Terima kasih! 🦷');
  window.open(`https://wa.me/${whatsappNumber}?text=${message}`, '_blank');
};
```

### Lokasi 2: Form Booking (Button dengan form lengkap)
Baris ~37-51:
```javascript
const message = `*BOOKING APPOINTMENT - BrightSmile Dental*

📋 *Data Pasien:*
👤 Nama: ${formData.name}
📧 Email: ${formData.email}
📱 Telepon: ${formData.phone}
📅 Tanggal Pilihan: ${formData.date}

💬 *Keluhan/Kebutuhan:*
${formData.message || 'Tidak ada catatan khusus'}

---
Mohon konfirmasi ketersediaan jadwal. Terima kasih! 🦷`;
```

**Tips:** Ubah teks di dalam backtick (``) atau tanda petik ('') sesuai kebutuhan Anda!

---

## ❓ FAQ

**Q: Apakah perlu akun WhatsApp Business?**  
A: Tidak perlu! WhatsApp biasa sudah cukup.

**Q: Apakah gratis?**  
A: 100% gratis! Tidak perlu bayar API atau subscription.

**Q: Apakah data booking tersimpan?**  
A: Tidak. Semua pesan langsung ke WhatsApp Anda. Tidak ada database.

**Q: Bisa pakai nomor luar negeri?**  
A: Bisa! Ganti angka 62 dengan kode negara lain. Contoh: +1 (Amerika) = 1, +60 (Malaysia) = 60

---

## 🎉 Selamat! Website Anda Siap Digunakan!

Jika ada pertanyaan, hubungi developer Anda.
