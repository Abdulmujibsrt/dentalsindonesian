import { useState } from 'react';
import { Menu, X, Phone, Mail, MapPin, Calendar, Clock, Smile, Shield, Award, Users, Star } from 'lucide-react';
import { Button } from './components/ui/button';
import { Card, CardContent } from './components/ui/card';
import { Input } from './components/ui/input';
import { Textarea } from './components/ui/textarea';
import heroImage from 'figma:asset/cda98fd26fb263c393df654783989efde25a145f.png';

export default function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    message: ''
  });

  // Nomor WhatsApp Admin (GANTI DENGAN NOMOR ANDA)
  // Format: 62812345678xx (tanpa +, -, atau spasi)
  const whatsappNumber = '6289530228432'; // Nomor WhatsApp Aktif

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Format pesan WhatsApp
    const message = `*BOOKING APPOINTMENT - BrightSmile Dental*

📋 *Data Pasien:*
👤 Nama: ${formData.name}
📧 Email: ${formData.email}
📱 Telepon: ${formData.phone}
📅 Tanggal Pilihan: ${formData.date}

💬 *Keluhan/Kebutuhan:*
${formData.message || 'Tidak ada catatan khusus'}

---
Mohon konfirmasi ketersediaan jadwal. Terima kasih! 🦷`;

    // Encode pesan untuk URL
    const encodedMessage = encodeURIComponent(message);
    
    // Redirect ke WhatsApp
    window.open(`https://wa.me/${whatsappNumber}?text=${encodedMessage}`, '_blank');
    
    // Reset form
    setFormData({
      name: '',
      email: '',
      phone: '',
      date: '',
      message: ''
    });
  };

  const handleQuickBooking = () => {
    const message = encodeURIComponent('Halo! Saya ingin booking appointment di BrightSmile Dental. Mohon informasi jadwal yang tersedia. Terima kasih! 🦷');
    window.open(`https://wa.me/${whatsappNumber}?text=${message}`, '_blank');
  };

  const services = [
    {
      icon: Smile,
      title: "General Dentistry",
      description: "Comprehensive dental care including cleanings, fillings, and preventive treatments."
    },
    {
      icon: Sparkles,
      title: "Cosmetic Dentistry",
      description: "Transform your smile with whitening, veneers, and aesthetic procedures."
    },
    {
      icon: Shield,
      title: "Preventive Care",
      description: "Regular checkups and screenings to maintain optimal oral health."
    },
    {
      icon: Users,
      title: "Family Dentistry",
      description: "Quality dental care for patients of all ages in a comfortable environment."
    }
  ];

  const testimonials = [
    {
      name: "Sarah Johnson",
      text: "Dr. Smith and the team are absolutely wonderful! They made me feel comfortable and my smile has never looked better.",
      rating: 5
    },
    {
      name: "Michael Chen",
      text: "Best dental experience I've ever had. Professional, friendly, and painless procedures. Highly recommend!",
      rating: 5
    },
    {
      name: "Emily Rodriguez",
      text: "The staff is so welcoming and caring. They truly care about their patients' comfort and health.",
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Navigation */}
      <nav className="fixed w-full bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 shadow-lg z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <Smile className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
              <span className="font-semibold text-lg sm:text-xl text-white">BrightSmile Dental</span>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-4 lg:gap-8">
              <a href="#services" className="text-white hover:text-yellow-200 transition-colors text-sm lg:text-base">Services</a>
              <a href="#about" className="text-white hover:text-yellow-200 transition-colors text-sm lg:text-base">About</a>
              <a href="#testimonials" className="text-white hover:text-yellow-200 transition-colors text-sm lg:text-base">Testimonials</a>
              <a href="#contact" className="text-white hover:text-yellow-200 transition-colors text-sm lg:text-base">Contact</a>
              <Button onClick={handleQuickBooking} className="text-sm lg:text-base bg-white text-purple-600 hover:bg-yellow-200 hover:text-purple-700">Book Appointment</Button>
            </div>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden text-white"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 border-t border-white/20">
            <div className="px-4 py-4 space-y-3">
              <a href="#services" className="block text-white hover:text-yellow-200" onClick={() => setMobileMenuOpen(false)}>Services</a>
              <a href="#about" className="block text-white hover:text-yellow-200" onClick={() => setMobileMenuOpen(false)}>About</a>
              <a href="#testimonials" className="block text-white hover:text-yellow-200" onClick={() => setMobileMenuOpen(false)}>Testimonials</a>
              <a href="#contact" className="block text-white hover:text-yellow-200" onClick={() => setMobileMenuOpen(false)}>Contact</a>
              <Button onClick={handleQuickBooking} className="w-full bg-white text-purple-600 hover:bg-yellow-200 hover:text-purple-700">Book Appointment</Button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="pt-24 pb-12 sm:pt-28 sm:pb-16 lg:pt-32 lg:pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            {/* Image - Shows first on mobile/tablet, second on desktop */}
            <div className="relative h-[300px] sm:h-[400px] lg:h-[500px] rounded-2xl overflow-hidden shadow-2xl order-1 lg:order-2">
              <div className="absolute inset-0 bg-gradient-to-tr from-blue-600/20 to-purple-600/20 z-10"></div>
              <img 
                src={heroImage}
                alt="Promo Gigi Palsu - Berkah Dental"
                className="w-full h-full object-cover"
              />
            </div>
            
            {/* Text - Shows second on mobile/tablet, first on desktop */}
            <div className="text-center lg:text-left order-2 lg:order-1">
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl mb-4 sm:mb-6 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                Your Smile, Our Priority
              </h1>
              <p className="text-base sm:text-lg lg:text-xl text-gray-700 mb-6 sm:mb-8">
                Experience exceptional dental care in a comfortable, modern environment. We're committed to helping you achieve and maintain a healthy, beautiful smile.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Button onClick={handleQuickBooking} size="lg" className="text-base sm:text-lg px-6 sm:px-8 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                  <Calendar className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                  Schedule Appointment
                </Button>
                <Button onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })} size="lg" variant="outline" className="text-base sm:text-lg px-6 sm:px-8 border-2 border-purple-600 text-purple-600 hover:bg-purple-50">
                  Learn More
                </Button>
              </div>
              <div className="mt-8 sm:mt-12 grid grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
                <div className="text-center lg:text-left">
                  <div className="flex items-center justify-center lg:justify-start gap-2 mb-2">
                    <Award className="w-4 h-4 sm:w-5 sm:h-5 text-purple-600" />
                  </div>
                  <div className="text-lg sm:text-xl lg:text-2xl">15+ Years</div>
                  <div className="text-xs sm:text-sm text-gray-600">Experience</div>
                </div>
                <div className="text-center lg:text-left">
                  <div className="flex items-center justify-center lg:justify-start gap-2 mb-2">
                    <Users className="w-4 h-4 sm:w-5 sm:h-5 text-purple-600" />
                  </div>
                  <div className="text-lg sm:text-xl lg:text-2xl">10,000+</div>
                  <div className="text-xs sm:text-sm text-gray-600">Happy Patients</div>
                </div>
                <div className="text-center lg:text-left">
                  <div className="flex items-center justify-center lg:justify-start gap-2 mb-2">
                    <Star className="w-4 h-4 sm:w-5 sm:h-5 text-purple-600" />
                  </div>
                  <div className="text-lg sm:text-xl lg:text-2xl">5.0 Rating</div>
                  <div className="text-xs sm:text-sm text-gray-600">Google Reviews</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-12 sm:py-16 lg:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-purple-100 via-pink-100 to-blue-100">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl mb-3 sm:mb-4 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Our Services</h2>
            <p className="text-base sm:text-lg lg:text-xl text-gray-700 max-w-2xl mx-auto px-4">
              Comprehensive dental care tailored to your unique needs
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
            {services.map((service, index) => (
              <Card key={index} className="hover:shadow-xl transition-all hover:-translate-y-1 bg-white/80 backdrop-blur-sm border-2 border-purple-200">
                <CardContent className="p-4 sm:p-6">
                  <service.icon className="w-10 h-10 sm:w-12 sm:h-12 text-purple-600 mb-3 sm:mb-4" />
                  <h3 className="text-lg sm:text-xl mb-2 sm:mb-3">{service.title}</h3>
                  <p className="text-sm sm:text-base text-gray-600">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-12 sm:py-16 lg:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-100 via-purple-100 to-pink-100">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <div className="relative h-[300px] sm:h-[400px] rounded-2xl overflow-hidden shadow-xl order-2 lg:order-1">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 to-pink-600/20 z-10"></div>
              <img 
                src="https://images.unsplash.com/photo-1673865641073-4479f93a7776?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50aXN0JTIwcGF0aWVudCUyMHNtaWxlfGVufDF8fHx8MTc2NTkxNTQyM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Dentist with patient"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="order-1 lg:order-2">
              <h2 className="text-3xl sm:text-4xl lg:text-5xl mb-4 sm:mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Excellence in Dental Care</h2>
              <p className="text-base sm:text-lg text-gray-700 mb-4 sm:mb-6">
                At BrightSmile Dental, we believe everyone deserves a healthy, confident smile. Our experienced team combines state-of-the-art technology with compassionate care to deliver exceptional results.
              </p>
              <p className="text-base sm:text-lg text-gray-700 mb-6 sm:mb-8">
                We take the time to understand your concerns and goals, creating personalized treatment plans that fit your needs and budget.
              </p>
              <div className="space-y-4">
                <div className="flex items-start gap-3 bg-white/60 backdrop-blur-sm p-3 sm:p-4 rounded-lg">
                  <Shield className="w-5 h-5 sm:w-6 sm:h-6 text-purple-600 flex-shrink-0 mt-1" />
                  <div>
                    <div className="text-base sm:text-lg">Advanced Technology</div>
                    <p className="text-xs sm:text-sm text-gray-600">Latest dental equipment for precise, comfortable treatments</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 bg-white/60 backdrop-blur-sm p-3 sm:p-4 rounded-lg">
                  <Users className="w-5 h-5 sm:w-6 sm:h-6 text-purple-600 flex-shrink-0 mt-1" />
                  <div>
                    <div className="text-base sm:text-lg">Experienced Team</div>
                    <p className="text-xs sm:text-sm text-gray-600">Highly trained professionals dedicated to your care</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 bg-white/60 backdrop-blur-sm p-3 sm:p-4 rounded-lg">
                  <Smile className="w-5 h-5 sm:w-6 sm:h-6 text-purple-600 flex-shrink-0 mt-1" />
                  <div>
                    <div className="text-base sm:text-lg">Patient-Centered Care</div>
                    <p className="text-xs sm:text-sm text-gray-600">Your comfort and satisfaction are our top priorities</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-12 sm:py-16 lg:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-pink-100 via-purple-100 to-blue-100">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8 sm:mb-12">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl mb-3 sm:mb-4 bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">What Our Patients Say</h2>
            <p className="text-base sm:text-lg lg:text-xl text-gray-700 px-4">Don't just take our word for it</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-white/80 backdrop-blur-sm border-2 border-pink-200 hover:shadow-xl transition-all hover:-translate-y-1">
                <CardContent className="p-4 sm:p-6">
                  <div className="flex gap-1 mb-3 sm:mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 sm:w-5 sm:h-5 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-sm sm:text-base text-gray-600 mb-3 sm:mb-4">{testimonial.text}</p>
                  <p className="text-base sm:text-lg">{testimonial.name}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-12 sm:py-16 lg:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-100 via-purple-100 to-pink-100">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
            <div>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl mb-4 sm:mb-6 bg-gradient-to-r from-blue-600 to-pink-600 bg-clip-text text-transparent">Get In Touch</h2>
              <p className="text-base sm:text-lg text-gray-700 mb-6 sm:mb-8">
                Ready to start your journey to a healthier smile? Contact us today to schedule your appointment.
              </p>
              
              <div className="space-y-4 sm:space-y-6 mb-6 sm:mb-8">
                <div className="flex items-start gap-3 sm:gap-4 bg-white/60 backdrop-blur-sm p-3 sm:p-4 rounded-lg">
                  <Phone className="w-5 h-5 sm:w-6 sm:h-6 text-purple-600 flex-shrink-0 mt-1" />
                  <div>
                    <div className="text-sm sm:text-base">Phone</div>
                    <a href="tel:555-123-4567" className="text-purple-600 text-sm sm:text-base">(555) 123-4567</a>
                  </div>
                </div>
                <div className="flex items-start gap-3 sm:gap-4 bg-white/60 backdrop-blur-sm p-3 sm:p-4 rounded-lg">
                  <Mail className="w-5 h-5 sm:w-6 sm:h-6 text-purple-600 flex-shrink-0 mt-1" />
                  <div>
                    <div className="text-sm sm:text-base">Email</div>
                    <a href="mailto:info@brightsmiledental.com" className="text-purple-600 text-sm sm:text-base break-all">info@brightsmiledental.com</a>
                  </div>
                </div>
                <div className="flex items-start gap-3 sm:gap-4 bg-white/60 backdrop-blur-sm p-3 sm:p-4 rounded-lg">
                  <MapPin className="w-5 h-5 sm:w-6 sm:h-6 text-purple-600 flex-shrink-0 mt-1" />
                  <div>
                    <div className="text-sm sm:text-base">Address</div>
                    <p className="text-gray-600 text-sm sm:text-base">123 Main Street, Suite 200<br />Anytown, ST 12345</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 sm:gap-4 bg-white/60 backdrop-blur-sm p-3 sm:p-4 rounded-lg">
                  <Clock className="w-5 h-5 sm:w-6 sm:h-6 text-purple-600 flex-shrink-0 mt-1" />
                  <div>
                    <div className="text-sm sm:text-base">Hours</div>
                    <p className="text-gray-600 text-sm sm:text-base">
                      Mon-Fri: 8:00 AM - 6:00 PM<br />
                      Sat: 9:00 AM - 2:00 PM<br />
                      Sun: Closed
                    </p>
                  </div>
                </div>
              </div>

              <div className="relative h-[200px] sm:h-[250px] lg:h-[300px] rounded-xl overflow-hidden shadow-lg">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 to-pink-600/20 z-10"></div>
                <img 
                  src="https://images.unsplash.com/photo-1758205308179-4e00e0e4060b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZW50YWwlMjBvZmZpY2UlMjBwcm9mZXNzaW9uYWx8ZW58MXx8fHwxNzY1OTYwMzMwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Dental office"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            <div>
              <Card className="bg-white/80 backdrop-blur-sm border-2 border-purple-200 shadow-xl">
                <CardContent className="p-4 sm:p-6 lg:p-8">
                  <h3 className="text-xl sm:text-2xl mb-4 sm:mb-6 text-purple-600">Request an Appointment</h3>
                  <form className="space-y-3 sm:space-y-4" onSubmit={handleBookingSubmit}>
                    <div>
                      <Input type="text" placeholder="Full Name" name="name" value={formData.name} onChange={handleInputChange} className="text-sm sm:text-base" />
                    </div>
                    <div>
                      <Input type="email" placeholder="Email Address" name="email" value={formData.email} onChange={handleInputChange} className="text-sm sm:text-base" />
                    </div>
                    <div>
                      <Input type="tel" placeholder="Phone Number" name="phone" value={formData.phone} onChange={handleInputChange} className="text-sm sm:text-base" />
                    </div>
                    <div>
                      <Input type="date" placeholder="Preferred Date" name="date" value={formData.date} onChange={handleInputChange} className="text-sm sm:text-base" />
                    </div>
                    <div>
                      <Textarea 
                        placeholder="Tell us about your dental needs..."
                        rows={4}
                        name="message"
                        value={formData.message}
                        onChange={handleInputChange}
                        className="text-sm sm:text-base"
                      />
                    </div>
                    <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-sm sm:text-base" size="lg">
                      Submit Request
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900 text-white py-8 sm:py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 mb-6 sm:mb-8">
            <div className="text-center sm:text-left">
              <div className="flex items-center gap-2 mb-3 sm:mb-4 justify-center sm:justify-start">
                <Smile className="w-6 h-6 sm:w-8 sm:h-8 text-purple-400" />
                <span className="font-semibold text-lg sm:text-xl">BrightSmile Dental</span>
              </div>
              <p className="text-gray-300 text-sm sm:text-base">
                Your trusted partner for comprehensive dental care and beautiful smiles.
              </p>
            </div>
            <div className="text-center sm:text-left">
              <h4 className="mb-3 sm:mb-4 text-base sm:text-lg">Quick Links</h4>
              <ul className="space-y-2 text-gray-300 text-sm sm:text-base">
                <li><a href="#services" className="hover:text-white transition-colors">Services</a></li>
                <li><a href="#about" className="hover:text-white transition-colors">About Us</a></li>
                <li><a href="#testimonials" className="hover:text-white transition-colors">Testimonials</a></li>
                <li><a href="#contact" className="hover:text-white transition-colors">Contact</a></li>
              </ul>
            </div>
            <div className="text-center sm:text-left">
              <h4 className="mb-3 sm:mb-4 text-base sm:text-lg">Services</h4>
              <ul className="space-y-2 text-gray-300 text-sm sm:text-base">
                <li>General Dentistry</li>
                <li>Cosmetic Dentistry</li>
                <li>Preventive Care</li>
                <li>Family Dentistry</li>
              </ul>
            </div>
            <div className="text-center sm:text-left">
              <h4 className="mb-3 sm:mb-4 text-base sm:text-lg">Contact Info</h4>
              <ul className="space-y-2 text-gray-300 text-sm sm:text-base">
                <li>(555) 123-4567</li>
                <li className="break-all">info@brightsmiledental.com</li>
                <li>123 Main Street, Suite 200</li>
                <li>Anytown, ST 12345</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 pt-6 sm:pt-8 text-center text-gray-300 text-sm sm:text-base">
            <p>&copy; 2024 BrightSmile Dental. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

import { Sparkles } from 'lucide-react';