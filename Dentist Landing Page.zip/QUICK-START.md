# ⚡ QUICK START - DEPLOY KE VERCEL

## 🎯 Langkah Cepat (5 Menit)

### 1. Download Website Dari Figma Make
- Klik tombol **Download** atau **Export**
- Ekstrak file ZIP jika perlu

### 2. Buka Vercel
- Ketik: **https://vercel.com**
- Klik **"Sign Up"** atau **"Login"**
- Pilih: **Continue with GitHub** atau **Continue with Google**

### 3. Upload Website
1. Di Vercel Dashboard → Klik **"Add New..."** (pojok kanan atas)
2. Pilih **"Project"**
3. **DRAG & DROP** folder website Anda
4. Klik **"Deploy"**
5. Tunggu 2-3 menit ⏱️

### 4. Website Online! 🎉
- Anda akan dapat domain gratis: `your-name.vercel.app`
- Klik link tersebut untuk buka website
- **SELESAI!** Website sudah online 24/7 ✅

---

## 📋 File Penting Yang Harus Ada

Pastikan folder website Anda punya file-file ini:

```
✅ package.json
✅ vite.config.ts
✅ index.html
✅ src/app/App.tsx
✅ src/styles/index.css
```

Jika file-file ini ada → **Pasti sukses deploy!**

---

## 🔧 Settings Vercel (Otomatis Terdeteksi)

```
Framework: Vite
Build Command: npm run build
Output Directory: dist
Install Command: npm install
Node Version: 18.x
```

Vercel akan otomatis detect settings ini. **Tidak perlu ubah apa-apa!**

---

## ❌ Jika Ada Error

### Error: "Build Failed"
**Solusi:**
1. Vercel Dashboard → **Settings** → **General**
2. Scroll ke **"Build & Development Settings"**
3. Ubah **Framework Preset** menjadi: `Vite`
4. **Save** → Klik **"Deployments"** → **"Redeploy"**

### Error: Halaman Kosong
**Solusi:**
1. Check nomor WhatsApp di `/src/app/App.tsx` baris 20
2. Pastikan: `const whatsappNumber = '6289530228432';`
3. Redeploy

### Error: Gambar Tidak Muncul
**Solusi:**
- Pastikan semua gambar sudah di-import dengan benar
- Check file `App.tsx` ada line: `import heroImage from 'figma:asset/...'`
- Redeploy

---

## 🌐 Domain Gratis vs Custom

| | Domain Gratis | Domain Custom |
|---|---|---|
| **Link** | `berkah-dental.vercel.app` | `www.berkahdental.com` |
| **Biaya** | 100% GRATIS | ~Rp 150k/tahun |
| **Cocok untuk** | Testing, portofolio | Bisnis serius |
| **SSL (HTTPS)** | ✅ Otomatis | ✅ Otomatis |
| **Hosting** | ✅ Gratis selamanya | ✅ Gratis selamanya |

**Rekomendasi:**
- Mulai dengan **domain gratis** dulu
- Jika bisnis berkembang → beli domain custom

---

## 📱 Informasi Website Anda

- **WhatsApp Admin:** +62 895-3022-8432
- **Framework:** React + TypeScript + Tailwind CSS
- **Hosting:** Vercel (Gratis)
- **SSL:** Otomatis (HTTPS)
- **CDN:** Global (website cepat di seluruh dunia)

---

## 🚀 Setelah Online

### Share Website Anda:
✅ Copy link: `your-website.vercel.app`  
✅ Share ke Instagram, Facebook, WhatsApp  
✅ Tambahkan ke Google My Business  
✅ Pasang di bio Instagram/TikTok  

### Test Semua Fitur:
✅ Button "Book Appointment" → harus buka WhatsApp  
✅ Form booking → harus kirim ke WhatsApp dengan format benar  
✅ Responsive di mobile (test buka di HP)  
✅ Semua gambar muncul  

---

## 📖 Panduan Lengkap

Lihat file: **`PANDUAN-DEPLOY-VERCEL.md`** untuk tutorial detail dengan screenshot!

---

## 💪 Anda Siap!

**3 langkah mudah:**
1. Download code
2. Upload ke Vercel
3. Website online!

**Selamat mencoba!** 🎉
