# 🚀 PANDUAN LENGKAP DEPLOY KE VERCEL

## 📋 DAFTAR ISI
1. [Persiapan](#persiapan)
2. [Download Code dari Figma Make](#download-code)
3. [Upload ke Vercel](#upload-vercel)
4. [Troubleshooting](#troubleshooting)
5. [Cara Ganti Domain Custom](#domain-custom)

---

## 1️⃣ PERSIAPAN {#persiapan}

### Yang Anda Butuhkan:
- ✅ Akun Google/GitHub (untuk login Vercel)
- ✅ Koneksi internet stabil
- ✅ Browser (Chrome/Firefox/Edge)
- ✅ File website dari Figma Make

### Waktu yang Dibutuhkan:
- ⏱️ **5-10 menit** (sangat cepat!)

---

## 2️⃣ DOWNLOAD CODE DARI FIGMA MAKE {#download-code}

### Langkah 1: Export Code dari Figma Make

**Cara A: Tombol Download (Jika Ada)**
1. Klik tombol **"Export"** atau **"Download"** di Figma Make
2. Pilih format **ZIP** atau **All Files**
3. Tunggu proses download selesai
4. File akan tersimpan di folder **Downloads** Anda

**Cara B: Manual Export**
1. Pilih semua file di Figma Make
2. Klik kanan → **Download** atau **Export**
3. Simpan semua file dalam 1 folder

### Langkah 2: Ekstrak File (Jika ZIP)

1. Buka folder **Downloads**
2. Cari file **website-anda.zip**
3. **Klik kanan** → **Extract All** (Windows) atau **Unzip** (Mac)
4. Folder website Anda akan muncul

### Langkah 3: Cek Struktur Folder

Pastikan struktur folder seperti ini:

```
website-anda/
├── src/
│   ├── app/
│   │   ├── App.tsx
│   │   └── components/
│   ├── styles/
│   │   ├── index.css
│   │   ├── theme.css
│   │   └── fonts.css
│   └── imports/
├── public/
├── package.json
├── index.html
├── vite.config.ts
└── tsconfig.json
```

✅ **Jika ada file-file di atas, Anda siap upload ke Vercel!**

---

## 3️⃣ UPLOAD KE VERCEL {#upload-vercel}

### Metode 1: UPLOAD LANGSUNG (PALING MUDAH) ⭐ RECOMMENDED

#### Step 1: Buka Vercel
1. Buka browser Anda
2. Ketik: **https://vercel.com**
3. Klik tombol **"Sign Up"** (Daftar) atau **"Login"**

#### Step 2: Login/Daftar
**Pilihan Login:**
- ✅ **Continue with GitHub** (Recommended)
- ✅ **Continue with Google**
- ✅ **Continue with Email**

**Saya Rekomendasikan: GitHub** (karena lebih mudah untuk update website nanti)

**Jika belum punya GitHub:**
1. Buka: **https://github.com**
2. Klik **"Sign Up"**
3. Isi: Username, Email, Password
4. Verifikasi email
5. Kembali ke Vercel dan login dengan GitHub

#### Step 3: Upload Project
1. Setelah login, Anda akan masuk ke **Vercel Dashboard**
2. Klik tombol **"Add New..."** (pojok kanan atas)
3. Pilih **"Project"**
4. Pilih **"Browse"** atau **"Upload folder"**
5. **DRAG & DROP** folder website Anda ke kotak upload
   - Atau klik **"Browse"** dan pilih folder website

#### Step 4: Konfigurasi Project
Vercel akan otomatis detect settingan. Pastikan:

**Framework Preset:** `Vite`  
**Root Directory:** `./` (biarkan default)  
**Build Command:** `npm run build` (sudah otomatis)  
**Output Directory:** `dist` (sudah otomatis)

✅ **Jika sudah benar, klik tombol "Deploy"**

#### Step 5: Tunggu Proses Deploy
- ⏱️ Proses deploy sekitar **1-3 menit**
- Anda akan melihat animasi loading
- **JANGAN tutup browser** sampai selesai

#### Step 6: Website Online! 🎉
1. Setelah selesai, Anda akan melihat pesan: **"Congratulations!"**
2. Anda akan mendapat domain gratis, contoh:
   - `your-website-abc123.vercel.app`
   - `berkah-dental-xyz.vercel.app`
3. **Klik link domain** untuk membuka website Anda
4. **WEBSITE SUDAH ONLINE!** ✅

---

### Metode 2: UPLOAD VIA GITHUB (UNTUK YANG PAHAM GIT)

#### Step 1: Upload Code ke GitHub
1. Login ke **GitHub.com**
2. Klik tombol **"New Repository"** (pojok kanan atas)
3. Isi:
   - **Repository name:** `berkah-dental-website`
   - **Public** atau **Private** (pilih Public agar gratis)
4. Klik **"Create repository"**
5. Upload semua file website Anda ke repository:
   - Klik **"uploading an existing file"**
   - **Drag & drop** semua file
   - Klik **"Commit changes"**

#### Step 2: Connect GitHub ke Vercel
1. Buka **Vercel.com** dan login
2. Klik **"Add New..."** → **"Project"**
3. Pilih **"Import Git Repository"**
4. Pilih repository GitHub Anda: `berkah-dental-website`
5. Klik **"Import"**
6. Klik **"Deploy"**
7. Tunggu 1-3 menit
8. **Website online!** ✅

---

## 4️⃣ TROUBLESHOOTING (JIKA ADA ERROR) {#troubleshooting}

### ❌ Error: "Build Failed"

**Solusi 1: Cek package.json**
Pastikan file `package.json` ada di root folder.

**Solusi 2: Ganti Build Settings**
Di Vercel Dashboard:
1. Klik **"Settings"** (tab atas)
2. Klik **"General"** (sidebar kiri)
3. Scroll ke **"Build & Development Settings"**
4. Ubah:
   - **Framework Preset:** `Vite`
   - **Build Command:** `npm run build`
   - **Output Directory:** `dist`
   - **Install Command:** `npm install`
5. Klik **"Save"**
6. Klik **"Deployments"** → **"Redeploy"**

**Solusi 3: Cek Node Version**
Di Vercel Dashboard:
1. Klik **"Settings"** → **"Environment Variables"**
2. Tambahkan variable baru:
   - **Key:** `NODE_VERSION`
   - **Value:** `18`
3. Klik **"Save"**
4. Redeploy

---

### ❌ Error: "Page Not Found" / Halaman Kosong

**Solusi:**
1. Buka Vercel Dashboard
2. Klik project Anda
3. Klik **"Settings"** → **"General"**
4. Scroll ke **"Root Directory"**
5. Pastikan: `./` (dot slash)
6. Klik **"Save"**
7. Redeploy

---

### ❌ Error: Gambar Tidak Muncul

**Solusi:**
1. Pastikan semua file gambar ada di folder `public/` atau diimport dengan benar
2. Check code di `App.tsx`:
   ```tsx
   // Correct:
   import heroImage from 'figma:asset/abc123.png';
   
   // Or:
   <img src="/images/hero.png" />
   ```
3. Redeploy

---

### ❌ WhatsApp Button Tidak Jalan

**Cek Nomor WhatsApp:**
1. Buka file `/src/app/App.tsx`
2. Cari baris:
   ```javascript
   const whatsappNumber = '6289530228432';
   ```
3. Pastikan nomor benar (tanpa +, -, spasi)
4. Save dan redeploy

---

## 5️⃣ CARA GANTI DOMAIN CUSTOM {#domain-custom}

### Step 1: Beli Domain

**Rekomendasi Provider (Indonesia):**
- ✅ **Niagahoster** - https://niagahoster.co.id (Rp 15k - 150k/tahun)
- ✅ **Dewaweb** - https://dewaweb.com (Rp 100k - 200k/tahun)
- ✅ **Domainesia** - https://domainesia.com (Rp 150k/tahun)

**Rekomendasi Provider (International):**
- ✅ **Namecheap** - https://namecheap.com ($8 - $12/tahun = ~Rp 120k)
- ✅ **GoDaddy** - https://godaddy.com ($10 - $15/tahun = ~Rp 150k)

**Tips Pilih Domain:**
- Pilih ekstensi `.com` (paling populer)
- Atau `.id` jika untuk Indonesia
- Pilih nama yang mudah diingat
- Contoh: `berkahdental.com`, `klinikgigisenyum.id`

### Step 2: Hubungkan Domain ke Vercel

#### A. Di Vercel Dashboard:
1. Login ke **Vercel.com**
2. Pilih **project** website Anda
3. Klik tab **"Settings"** (atas)
4. Klik **"Domains"** (sidebar kiri)
5. Ketik domain Anda: `berkahdental.com`
6. Klik **"Add"**
7. Vercel akan memberikan **2 record DNS:**
   - **Type A** → Value: `76.76.21.21`
   - **Type CNAME** → Value: `cname.vercel-dns.com`

#### B. Di Website Domain Provider (Niagahoster/Namecheap/dll):
1. Login ke akun domain Anda
2. Cari menu **"DNS Management"** atau **"Manage DNS"**
3. **Hapus semua record lama** (A, CNAME, dll)
4. **Tambahkan record baru:**

**Record 1:**
- Type: `A`
- Name: `@` (atau kosongkan)
- Value: `76.76.21.21`
- TTL: `3600` (atau otomatis)

**Record 2:**
- Type: `CNAME`
- Name: `www`
- Value: `cname.vercel-dns.com`
- TTL: `3600` (atau otomatis)

5. Klik **"Save"** atau **"Update"**

#### C. Tunggu Propagasi DNS
- ⏱️ Biasanya **10 menit - 48 jam**
- Rata-rata: **1-2 jam** sudah bisa diakses
- Check status di Vercel Dashboard (akan muncul ✅ hijau jika sudah connected)

#### D. Test Domain Anda
1. Buka browser
2. Ketik domain Anda: `www.berkahdental.com`
3. **Website Anda muncul!** 🎉

---

## 🎯 CHECKLIST FINAL

Sebelum publish, pastikan:

- ✅ Nomor WhatsApp sudah diganti: `6289530228432`
- ✅ Semua button berfungsi (test klik)
- ✅ Form booking berfungsi
- ✅ Gambar semua muncul
- ✅ Responsive di mobile (buka di HP)
- ✅ Website load dengan cepat
- ✅ Tidak ada error di console browser (F12)

---

## 📱 CARA TEST SETELAH ONLINE

### Test 1: Buka di Desktop
1. Buka domain: `your-website.vercel.app`
2. Cek semua section scroll dengan smooth
3. Klik semua button pastikan jalan

### Test 2: Buka di Mobile
1. Buka di HP Anda
2. Test navigation menu (hamburger icon)
3. Test button WhatsApp
4. Test form booking

### Test 3: Test WhatsApp Integration
1. Klik button **"Book Appointment"**
2. WhatsApp harus terbuka otomatis
3. Pesan harus muncul dengan format yang benar
4. Isi form lengkap dan submit
5. WhatsApp harus terbuka dengan data yang diisi

---

## 💡 TIPS SETELAH ONLINE

### 1. Share ke Customer
- Copy link website: `your-website.vercel.app`
- Share ke WhatsApp, Instagram, Facebook
- Tambahkan ke Google My Business

### 2. Setup Google Analytics (Gratis)
Untuk tracking visitor:
1. Buat akun di **analytics.google.com**
2. Dapat **Tracking ID**: `G-XXXXXXXXXX`
3. Tambahkan ke website Anda
4. Bisa lihat berapa orang yang visit website

### 3. Update Website di Masa Depan
**Jika pakai Metode 1 (Upload Langsung):**
1. Edit code di Figma Make
2. Download lagi
3. Upload lagi ke Vercel (akan auto replace)

**Jika pakai Metode 2 (GitHub):**
1. Edit code di Figma Make
2. Upload ke GitHub (replace file)
3. Vercel otomatis update website (auto-deploy)

---

## 🆘 BUTUH BANTUAN?

**Jika masih bingung atau ada error:**

1. **Screenshot error message**
2. **Kirim ke WhatsApp support Vercel** (biasanya fast response)
3. **Atau hubungi developer Anda**

**Forum Support:**
- Vercel Discord: https://vercel.com/discord
- Vercel Docs: https://vercel.com/docs

---

## 🎉 SELAMAT!

**Website Anda sudah ONLINE!** 🚀

Fitur yang sudah jalan:
- ✅ Website bisa diakses 24/7
- ✅ WhatsApp booking otomatis
- ✅ Responsive di semua device
- ✅ Gratis selamanya (dengan domain `.vercel.app`)
- ✅ SSL/HTTPS otomatis (website aman)
- ✅ Load super cepat (CDN global)

**Sekarang waktunya promosikan website Anda dan dapatkan customer baru!** 💪

---

## 📞 INFORMASI KONTAK

Website Anda:
- Domain Sementara: `your-website.vercel.app` (ganti setelah deploy)
- WhatsApp Admin: **+62 895-3022-8432**

---

**Dibuat dengan ❤️ untuk membantu Anda sukses online!**
