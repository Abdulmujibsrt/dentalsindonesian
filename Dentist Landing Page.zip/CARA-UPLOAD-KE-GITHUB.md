# 📤 CARA UPLOAD WEBSITE KE GITHUB (Sangat Mudah!)

## 🎯 Kenapa Pakai GitHub?

✅ **Tidak perlu download ZIP** - Upload langsung dari browser  
✅ **Otomatis tersimpan** - Code aman di cloud  
✅ **Auto-deploy ke Vercel** - Sekali setup, update otomatis  
✅ **Gratis selamanya** - Tidak perlu bayar apa-apa  

---

## 📋 LANGKAH 1: DAFTAR/LOGIN KE GITHUB

### 1.1 Buka GitHub
- Ketik: **https://github.com**
- Tekan Enter

### 1.2 Daftar Akun (Jika Belum Punya)

**Klik tombol "Sign Up" (pojok kanan atas)**

Isi data:
1. **Email:** Masukkan email Anda (contoh: `email@gmail.com`)
2. **Password:** Buat password (minimal 8 karakter, pakai huruf + angka)
3. **Username:** Pilih username unik (contoh: `berkahdental`, `klinikgigi123`)
4. Klik **"Continue"**
5. Verifikasi captcha (centang "I'm not a robot")
6. Klik **"Create account"**

**Cek Email:**
- Buka email Anda
- Cari email dari GitHub
- Klik link verifikasi
- ✅ Akun GitHub siap!

### 1.3 Login (Jika Sudah Punya Akun)

- Klik **"Sign In"** (pojok kanan atas)
- Masukkan username/email + password
- Klik **"Sign in"**

---

## 📋 LANGKAH 2: BUAT REPOSITORY BARU

### 2.1 Klik Tombol "New"

Setelah login, cari tombol **hijau "New"** atau **"+"** (pojok kanan atas) → Pilih **"New repository"**

### 2.2 Isi Form Repository

**Repository name:** (Nama project Anda)
```
berkah-dental-website
```
*Tips: Pakai huruf kecil, tanpa spasi (pakai dash `-` jika perlu)*

**Description:** (Deskripsi - opsional)
```
Landing page untuk Berkah Dental dengan WhatsApp booking
```

**Public atau Private?**
- ✅ Pilih: **Public** (agar bisa deploy gratis ke Vercel)
- Private = berbayar untuk deploy

**Initialize repository:**
- ✅ **CENTANG:** "Add a README file"

### 2.3 Klik "Create repository"

✅ Repository berhasil dibuat!

---

## 📋 LANGKAH 3: UPLOAD FILE-FILE WEBSITE

### 3.1 Upload File Satu-Satu (CARA MUDAH)

Anda sekarang di halaman repository. Ikuti langkah ini:

#### A. Upload `package.json`

1. Klik tombol **"Add file"** (di atas list file)
2. Pilih **"Create new file"**
3. Di kotak **"Name your file..."**, ketik: `package.json`
4. Di kotak besar bawahnya, **copy-paste** isi file berikut:

<details>
<summary>📄 Klik untuk lihat isi package.json (COPY INI)</summary>

```json
{
  "name": "berkah-dental-website",
  "private": true,
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "lucide-react": "^0.487.0",
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "@radix-ui/react-slot": "^1.1.2",
    "class-variance-authority": "^0.7.1",
    "clsx": "^2.1.1",
    "tailwind-merge": "^3.2.0"
  },
  "devDependencies": {
    "@types/react": "^18.3.3",
    "@types/react-dom": "^18.3.0",
    "@vitejs/plugin-react": "^4.3.1",
    "typescript": "^5.5.3",
    "vite": "^6.3.5",
    "@tailwindcss/vite": "^4.1.12",
    "tailwindcss": "^4.1.12"
  }
}
```

</details>

5. Scroll ke bawah
6. Klik tombol hijau **"Commit new file"**

✅ File `package.json` berhasil di-upload!

---

#### B. Upload `index.html`

1. Klik **"Add file"** → **"Create new file"**
2. Nama file: `index.html`
3. Copy-paste isi berikut:

<details>
<summary>📄 Klik untuk lihat isi index.html (COPY INI)</summary>

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="BrightSmile Dental - Your trusted partner for comprehensive dental care and beautiful smiles. Book your appointment today!" />
    <title>BrightSmile Dental - Your Smile, Our Priority</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

</details>

4. Klik **"Commit new file"**

✅ Done!

---

#### C. Upload File `vite.config.ts`

Baca file vite.config.ts yang sudah ada di project Figma Make Anda, lalu upload dengan cara yang sama.

---

### 3.2 Upload Folder `src/`

Karena ada banyak file di folder `src/`, kita upload dengan cara berbeda:

#### Upload menggunakan "Upload files"

1. Klik **"Add file"** → **"Upload files"**
2. **Drag & drop** folder `src/` dari Figma Make Anda
3. Atau klik **"choose your files"** → Pilih semua file di folder `src/`
4. Tunggu upload selesai
5. Klik **"Commit changes"**

**Catatan:** Upload semua file ini:
- `src/main.tsx`
- `src/app/App.tsx`
- `src/app/components/` (semua file di dalamnya)
- `src/styles/` (semua file CSS)

---

## 📋 LANGKAH 4: CONNECT GITHUB KE VERCEL

### 4.1 Buka Vercel

- Ketik: **https://vercel.com**
- Klik **"Sign Up"** atau **"Login"**

### 4.2 Login dengan GitHub

**PENTING: Pilih "Continue with GitHub"**

1. Klik tombol **"Continue with GitHub"**
2. GitHub akan minta izin
3. Klik **"Authorize Vercel"** (tombol hijau)
4. ✅ GitHub dan Vercel sudah terhubung!

### 4.3 Import Repository

1. Di Vercel Dashboard, klik **"Add New..."** → **"Project"**
2. Anda akan lihat list repository GitHub Anda
3. Cari repository: **`berkah-dental-website`**
4. Klik tombol **"Import"** di sebelah kanan repository tersebut

### 4.4 Deploy!

1. Vercel akan otomatis detect settings:
   - Framework: **Vite**
   - Build Command: **`npm run build`**
   - Output Directory: **`dist`**
2. **Jangan ubah apa-apa!**
3. Klik tombol besar **"Deploy"** (berwarna biru/hitam)
4. Tunggu 2-3 menit ⏱️

### 4.5 Website Online! 🎉

Setelah selesai:
- ✅ Muncul pesan "Congratulations!"
- ✅ Dapat domain: `berkah-dental-xyz.vercel.app`
- ✅ **KLIK link tersebut untuk buka website!**

---

## 🔄 UPDATE WEBSITE DI MASA DEPAN

**Keuntungan pakai GitHub + Vercel:**

Jika nanti Anda ingin **update website** (ganti teks, gambar, dll):

1. Edit file di GitHub (klik file → klik icon pensil "Edit")
2. Save (klik "Commit changes")
3. **Vercel OTOMATIS update website** dalam 1-2 menit!
4. ✅ Tidak perlu upload ulang!

**AUTO-DEPLOY:** Setiap kali Anda update code di GitHub, Vercel otomatis deploy ulang! 🚀

---

## 📱 CHECKLIST FILE YANG HARUS DI-UPLOAD

Pastikan semua file ini ada di GitHub:

```
✅ package.json
✅ index.html
✅ vite.config.ts
✅ tsconfig.json
✅ src/main.tsx
✅ src/app/App.tsx
✅ src/app/components/ui/ (folder + isinya)
✅ src/styles/index.css
✅ src/styles/theme.css
✅ src/styles/fonts.css
✅ src/styles/tailwind.css
```

---

## ❓ TROUBLESHOOTING

### Problem: "Build Failed" di Vercel

**Solusi 1:** Cek apakah `package.json` sudah di-upload dengan benar

**Solusi 2:** Di Vercel:
1. Settings → Environment Variables
2. Tambahkan:
   - Key: `NODE_VERSION`
   - Value: `18`
3. Save → Redeploy

### Problem: File Tidak Ke-Upload

**Solusi:**
- Coba upload satu-satu menggunakan "Create new file"
- Atau gunakan GitHub Desktop (aplikasi desktop)

### Problem: GitHub Minta Verifikasi Email

**Solusi:**
1. Cek inbox email Anda
2. Cari email dari GitHub
3. Klik link "Verify email address"
4. Kembali ke GitHub dan refresh

---

## 🎯 KESIMPULAN

**3 Langkah Utama:**
1. ✅ Upload code ke **GitHub** (gratis)
2. ✅ Connect GitHub ke **Vercel** (sekali aja)
3. ✅ **Deploy** → Website online!

**Keuntungan:**
- ✅ Tidak perlu download ZIP
- ✅ Auto-deploy setiap kali update
- ✅ Code tersimpan aman
- ✅ 100% gratis selamanya

---

## 🆘 MASIH BINGUNG?

Jika Anda kesulitan, saya bisa bantu dengan cara lain:

**ALTERNATIF MUDAH:**
1. Screenshot semua file di Figma Make
2. Kirim ke developer/teman yang paham
3. Minta tolong upload ke GitHub

Atau hubungi support Vercel: https://vercel.com/support

---

**Selamat mencoba! Pasti bisa! 💪**
