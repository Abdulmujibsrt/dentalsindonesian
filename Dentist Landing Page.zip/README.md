# 🦷 BrightSmile Dental - Landing Page

Website landing page untuk klinik gigi dengan desain modern, colorful gradient, dan WhatsApp booking integration.

![Website Preview](https://img.shields.io/badge/Status-Ready%20to%20Deploy-success)
![React](https://img.shields.io/badge/React-18.3.1-blue)
![TypeScript](https://img.shields.io/badge/TypeScript-5.x-blue)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-4.1.12-38bdf8)

## ✨ Fitur Utama

- ✅ **WhatsApp Booking Integration** - Langsung terhubung ke WhatsApp admin
- ✅ **Responsive Design** - Sempurna di mobile, tablet, dan desktop
- ✅ **Modern UI/UX** - Gradient colorful (biru-ungu-pink)
- ✅ **Fast Performance** - Built with Vite + React
- ✅ **Form Booking** - Kirim detail booking ke WhatsApp otomatis
- ✅ **SEO Optimized** - Meta tags dan semantic HTML

## 🚀 Quick Deploy ke Vercel

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/yourusername/berkah-dental-website)

### Cara Deploy:

1. **Klik tombol "Deploy with Vercel" di atas** atau:
2. Login ke [Vercel.com](https://vercel.com)
3. Klik **"Add New..."** → **"Project"**
4. Import repository GitHub ini
5. Klik **"Deploy"**
6. Tunggu 2-3 menit
7. ✅ Website online!

## 📱 Info Kontak

- **WhatsApp Admin:** +62 895-3022-8432
- **Framework:** React + TypeScript + Vite
- **Styling:** Tailwind CSS v4
- **Hosting:** Vercel (Free)

## 🛠️ Tech Stack

- **React 18.3.1** - UI Framework
- **TypeScript** - Type Safety
- **Vite 6.3.5** - Build Tool
- **Tailwind CSS 4.1.12** - Styling
- **Radix UI** - Accessible Components
- **Lucide React** - Icons
- **Motion/React** - Animations

## 📂 Struktur Project

```
berkah-dental-website/
├── src/
│   ├── app/
│   │   ├── App.tsx              # Main component
│   │   └── components/
│   │       ├── ui/              # Reusable UI components
│   │       └── figma/           # Figma imported components
│   ├── styles/
│   │   ├── index.css            # Main styles
│   │   ├── theme.css            # Theme tokens
│   │   ├── fonts.css            # Font imports
│   │   └── tailwind.css         # Tailwind base
│   └── main.tsx                 # Entry point
├── public/                      # Static assets
├── package.json                 # Dependencies
├── vite.config.ts              # Vite configuration
└── index.html                   # HTML template
```

## 🔧 Development (Opsional)

Jika ingin edit di local:

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## 📝 Cara Ganti Nomor WhatsApp

Buka file `/src/app/App.tsx`, cari baris ~20:

```javascript
const whatsappNumber = '6289530228432'; // Ganti dengan nomor Anda
```

Ubah nomor sesuai kebutuhan (format: 628xxxxxxxxxx, tanpa +, -, atau spasi).

## 🌐 Domain Custom (Opsional)

Setelah deploy, website akan dapat domain gratis: `your-project.vercel.app`

Untuk domain custom (seperti `berkahdental.com`):
1. Beli domain di Niagahoster/Namecheap (~Rp 150k/tahun)
2. Di Vercel: Settings → Domains → Add domain
3. Update DNS di provider domain Anda
4. Tunggu propagasi (1-2 jam)

## 📄 License

© 2024 BrightSmile Dental. All rights reserved.

## 🙏 Credits

Built with ❤️ using Figma Make and deployed on Vercel.

---

**Made with Figma Make** | **Powered by Vercel**
